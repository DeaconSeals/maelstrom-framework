# maelstrom-framework
Strong-typed genetic programming framework with support for island models, competitive coevolution, and rapid prototyping
